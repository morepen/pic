import axios from 'axios';

// axios 配置
axios.defaults.timeout = 5000;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
axios.defaults.baseURL = 'http://localhost:8091/';


export function fetch(url, params) {
    return new Promise((resolve, reject) => {
        axios.post(url, params)
            .then(response => {
                resolve(response.data);
            }, err => {
                reject(err);
            })
            .catch((error) => {
               reject(error)
            })
    })
}

export default {
    /**
     * 用户登录
     */
    Login(params) {
        return fetch('/api/Public/LoginCheck', params)
    },
    
    /**
     * 用户注册
     */
    Regist(params) {
        return fetch('/api/Public/Register', params)
    },
    PicUpload(params){
       return fetch('/api/Public/PicUpload', params) 
    }
}
