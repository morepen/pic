<template>
  <div class="page">
    

<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/哈哈小姐" target="_blank">
            <img src="/avatar/default/7.jpg" alt="" width="50" height="50">
            <span class="name">哈哈小姐</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/哈哈小姐" target="_blank">哈哈小姐</a>
            <p class="ell"></p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5ad4164d46d01604d8511d12" target="_blank">这个功能不错</a></h3>
        <a href="/topic/5ad4164d46d01604d8511d12" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_4_16_11_19_15_69_0.4666584682767345.png/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(0, 'qq' ,'5ad4164d46d01604d8511d12')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(0, 'wb' ,'5ad4164d46d01604d8511d12')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5ad4164d46d01604d8511d12"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5ad4164d46d01604d8511d12">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5ad4164d46d01604d8511d12">
                <span><i class="iconfont"></i><em>1</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5ad4164d46d01604d8511d12" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5abcac3e46d01604d8511d08" target="_blank">地主先出农民怎么才能赢</a></h3>
        <a href="/topic/5abcac3e46d01604d8511d08" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_3_29_17_4_55_366_0.9467080454359607.png/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(1, 'qq' ,'5abcac3e46d01604d8511d08')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(1, 'wb' ,'5abcac3e46d01604d8511d08')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5abcac3e46d01604d8511d08"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5abcac3e46d01604d8511d08">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5abcac3e46d01604d8511d08">
                <span><i class="iconfont"></i><em>44</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5abcac3e46d01604d8511d08" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/愿祖国繁荣昌盛" target="_blank">
            <img src="/avatar/愿祖国繁荣昌盛.jpg" alt="" width="50" height="50">
            <span class="name">愿祖国繁荣昌盛</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/愿祖国繁荣昌盛" target="_blank">愿祖国繁荣昌盛</a>
            <p class="ell">有朋自远方来，虽远必诛…</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5abca3e546d01604d8511d05" target="_blank">支付宝你是认真的吗？</a></h3>
        <a href="/topic/5abca3e546d01604d8511d05" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_3_29_16_29_15_544_0.07610625055840048.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(2, 'qq' ,'5abca3e546d01604d8511d05')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(2, 'wb' ,'5abca3e546d01604d8511d05')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5abca3e546d01604d8511d05"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5abca3e546d01604d8511d05">
                <span><i class="iconfont"></i>0</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5abca3e546d01604d8511d05">
                <span><i class="iconfont"></i><em>29</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5abca3e546d01604d8511d05" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/好久好久以前还是个小屁孩" target="_blank">
            <img src="http://tva3.sinaimg.cn/crop.0.0.996.996.180/005VZ8Zqjw8ezhox7ep0xj30ro0rot9v.jpg" alt="" width="50" height="50">
            <span class="name">好久好久以前还是个小屁孩</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/好久好久以前还是个小屁孩" target="_blank">好久好久以前还是个小屁孩</a>
            <p class="ell"></p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5abca3e446d01604d8511d04" target="_blank">我就点了个再见，你特么又给我装回来了？</a></h3>
        <a href="/topic/5abca3e446d01604d8511d04" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_3_29_16_28_43_318_0.2800273429891589.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(3, 'qq' ,'5abca3e446d01604d8511d04')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(3, 'wb' ,'5abca3e446d01604d8511d04')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5abca3e446d01604d8511d04"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5abca3e446d01604d8511d04">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5abca3e446d01604d8511d04">
                <span><i class="iconfont"></i><em>30</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5abca3e446d01604d8511d04" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5abca2ee46d01604d8511cff" target="_blank">2018年计划</a></h3>
        <a href="/topic/5abca2ee46d01604d8511cff" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_3_29_16_25_9_635_0.8191746796436419.png/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(4, 'qq' ,'5abca2ee46d01604d8511cff')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(4, 'wb' ,'5abca2ee46d01604d8511cff')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5abca2ee46d01604d8511cff"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5abca2ee46d01604d8511cff">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5abca2ee46d01604d8511cff">
                <span><i class="iconfont"></i><em>31</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5abca2ee46d01604d8511cff" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/yangkinger" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/E9D73C0FEBE85DA8ECB4D0DAC35C2194/100" alt="" width="50" height="50">
            <span class="name">yangkinger</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/yangkinger" target="_blank">yangkinger</a>
            <p class="ell"></p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5a742ca9dfcb010a40673009" target="_blank">怀念星爷...</a></h3>
        <a href="/topic/5a742ca9dfcb010a40673009" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2018_2_2_17_14_52_735_0.15870365593202296.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(5, 'qq' ,'5a742ca9dfcb010a40673009')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(5, 'wb' ,'5a742ca9dfcb010a40673009')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5a742ca9dfcb010a40673009"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5a742ca9dfcb010a40673009">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5a742ca9dfcb010a40673009">
                <span><i class="iconfont"></i><em>22</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5a742ca9dfcb010a40673009" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/59fa94be8fa8ae08c8a86f7f" target="_blank">这个，这个有点过分了啊，哈哈哈哈</a></h3>
        <a href="/topic/59fa94be8fa8ae08c8a86f7f" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_10_16_16_47_29_287_0.9324871051407844.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(6, 'qq' ,'59fa94be8fa8ae08c8a86f7f')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(6, 'wb' ,'59fa94be8fa8ae08c8a86f7f')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/59fa94be8fa8ae08c8a86f7f"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="59fa94be8fa8ae08c8a86f7f">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="59fa94be8fa8ae08c8a86f7f">
                <span><i class="iconfont"></i><em>40</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="59fa94be8fa8ae08c8a86f7f" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/59f860598fa8ae08c8a86f7e" target="_blank">都学着点，我的925</a></h3>
        <a href="/topic/59f860598fa8ae08c8a86f7e" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_10_16_16_51_14_582_0.5973526409649783.png/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(7, 'qq' ,'59f860598fa8ae08c8a86f7e')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(7, 'wb' ,'59f860598fa8ae08c8a86f7e')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/59f860598fa8ae08c8a86f7e"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="59f860598fa8ae08c8a86f7e">
                <span><i class="iconfont"></i>3</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="59f860598fa8ae08c8a86f7e">
                <span><i class="iconfont"></i><em>69</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="59f860598fa8ae08c8a86f7e" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/59e471547f6eb50be4668234" target="_blank">晚上吃鸡。</a></h3>
        <a href="/topic/59e471547f6eb50be4668234" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_10_16_16_43_45_44_0.8996238547405306.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(8, 'qq' ,'59e471547f6eb50be4668234')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(8, 'wb' ,'59e471547f6eb50be4668234')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/59e471547f6eb50be4668234"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="59e471547f6eb50be4668234">
                <span><i class="iconfont"></i>1</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="59e471547f6eb50be4668234">
                <span><i class="iconfont"></i><em>94</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="59e471547f6eb50be4668234" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/59e46fe97f6eb50be4668231" target="_blank">最怕空气突然安静</a></h3>
        <a href="/topic/59e46fe97f6eb50be4668231" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_10_16_16_37_48_628_0.3768620046565707.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(9, 'qq' ,'59e46fe97f6eb50be4668231')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(9, 'wb' ,'59e46fe97f6eb50be4668231')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/59e46fe97f6eb50be4668231"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="59e46fe97f6eb50be4668231">
                <span><i class="iconfont"></i>0</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="59e46fe97f6eb50be4668231">
                <span><i class="iconfont"></i><em>40</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="59e46fe97f6eb50be4668231" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>
<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5997f020e5b9a00f2007a8bc" target="_blank">我发现一个腾讯内部的秘密。</a></h3>
        <a href="/topic/5997f020e5b9a00f2007a8bc" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_8_19_16_0_17_369_0.6287365225772157.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(17, 'qq' ,'5997f020e5b9a00f2007a8bc')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(17, 'wb' ,'5997f020e5b9a00f2007a8bc')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5997f020e5b9a00f2007a8bc"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5997f020e5b9a00f2007a8bc">
                <span><i class="iconfont"></i>0</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5997f020e5b9a00f2007a8bc">
                <span><i class="iconfont"></i><em>31</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5997f020e5b9a00f2007a8bc" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/我是小仙女啊" target="_blank">
            <img src="http://q.qlogo.cn/qqapp/101405320/8FEA2598F78DD97562C9A199CD9AF6A3/100" alt="" width="50" height="50">
            <span class="name">我是小仙女啊</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/我是小仙女啊" target="_blank">我是小仙女啊</a>
            <p class="ell">我才不懒呢╭(╯^╰)╮</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5997eebee5b9a00f2007a8ba" target="_blank">我手伸来了，水呢？</a></h3>
        <a href="/topic/5997eebee5b9a00f2007a8ba" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/2017_8_19_15_54_25_247_0.7109612183664482.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(18, 'qq' ,'5997eebee5b9a00f2007a8ba')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(18, 'wb' ,'5997eebee5b9a00f2007a8ba')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5997eebee5b9a00f2007a8ba"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5997eebee5b9a00f2007a8ba">
                <span><i class="iconfont"></i>0</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5997eebee5b9a00f2007a8ba">
                <span><i class="iconfont"></i><em>50</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5997eebee5b9a00f2007a8ba" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


<div class="post-item">
    <div class="post-head clearfix">
        <a class="avatar clearfix" href="/people/愿祖国繁荣昌盛" target="_blank">
            <img src="/avatar/愿祖国繁荣昌盛.jpg" alt="" width="50" height="50">
            <span class="name">愿祖国繁荣昌盛</span>
        </a>
        <div class="user-info">
            <a class="name" href="/people/愿祖国繁荣昌盛" target="_blank">愿祖国繁荣昌盛</a>
            <p class="ell">有朋自远方来，虽远必诛…</p>
        </div>
    </div>
    <div class="content">
        <h3 class="title content-title"><a href="/topic/5997edb4e5b9a00f2007a8b8" target="_blank">学生证是个好东西</a></h3>
        <a href="/topic/5997edb4e5b9a00f2007a8b8" target="_blank" class="picture">
            <img class="content-picture" src="http://on8trez75.bkt.clouddn.com/1290.jpg/mark" alt="">
        </a>
    </div>
    <div class="port">
        <div class="bar">
            <a href="javascript:void(0)" class="share-bn">
                <span><i class="iconfont"></i></span>
                <ul>
                    <li><span onclick="shareTo(19, 'qq' ,'5997edb4e5b9a00f2007a8b8')"><em class="iconfont"></em>QQ空间</span></li>
                    <li><span onclick="shareTo(19, 'wb' ,'5997edb4e5b9a00f2007a8b8')"><em class="iconfont"></em>新浪微博</span></li>
                    <li class="wx_code"><span><em class="iconfont"></em>微信</span><img src="http://qr.liantu.com/api.php?&amp;w=153&amp;text=laosij.cn/topic/5997edb4e5b9a00f2007a8b8"></li>
                </ul>
            </a>
            <a class="reply-button" href="javascript:void(0)" data-topic-id="5997edb4e5b9a00f2007a8b8">
                <span><i class="iconfont"></i>0</span>
            </a>
            <a class="like" href="javascript:void(0)" liked="0" data-topic-id="5997edb4e5b9a00f2007a8b8">
                <span><i class="iconfont"></i><em>26</em></span>
            </a>
        </div>
    </div>
    <div class="reply">
        <div class="default"><i class="iconfont"></i><span>加载中...</span></div>
        <div class="reply-wrap">

        </div>
        <div class="comment clearfix">
            <textarea class="comment-content" data-topic-id="5997edb4e5b9a00f2007a8b8" placeholder="大家都是文化人，有话好好说"></textarea>
            <span class="comment-bnt">发表评论</span>
        </div>
    </div>
</div>


    
<div id="paging">
    <ul class="clearfix">
        
                <li><a class="on" href="/p/1">1</a></li>
            
                <li><a href="/p/2">2</a></li>
            
                <li><a href="/p/3">3</a></li>
            
                <li><a href="/p/4">4</a></li>
            
                <li><a href="/p/5">5</a></li>
            

        
            <li><a href="/p/2">下一页</a></li>
        

        <li class="clearfix skip-to">
            <input id="skip-to" paging-link="/p/" class="skip-to" type="text" placeholder="">
            <a id="skip-bn" href="javascript:void(0)">跳转</a>
        </li>
    </ul>
</div>

    <script type="text/html" id="replyTemplate">
        <div class="reply-item clearfix">
            <a class="reply-head" href="">
                <img src="[avatar]" alt="" width="30" height="30">
            </a>
            <div class="reply-content">
                <a href="/people/[name]" target="_blank">[name]</a>
                <span>[text]</span>
            </div>
            <div class="reply-port clearfix">
                <div class="r">
                    <a class="reply-like-btn[liked]" href="javascript:void(0)" liked="[is-liked]" data-reply-id="[_id]"><i class="iconfont">&#xe872;</i><span>[like]</span></a>
                </div>
                <em>[floor]L</em>
            </div>
        </div>
    </script>
</div>
</template>

<script>
</script>
<style>
 .page {
    width: 760px;
    float: left;
    overflow: hidden;
}

.page .post-item {
    height: 100%;
    transition: all 0.3s;
    -webkit-transition: all 0.3s;
    border: 1px solid #e7eaf1;
    border-radius: 2px;
    box-shadow: 0 1px 3px rgba(0,37,55,.05);
    margin-bottom: 15px;
}

.page .post-item .post-head {
    padding: 30px;
    background: white;
    position: relative;
}

.page .post-item .post-head .avatar {
    float: left;
    border-radius: 50%;
    overflow: hidden;
}

.page .post-item .post-head .avatar .name {
    display: none;
}

.page .post-item .post-head .avatar img{
    display: block;
}

.page .post-item .post-head .user-info {
    float: left;
    padding-left: 20px;
    width: 570px;
}

.page .post-item .post-head .user-info .name {
    font-size: 14px;
    font-weight: bold;
    line-height: 25px;
}

.page .post-item .post-head .user-info .name:hover {
    color: #3498DB;
}

.page .post-item .post-head .user-info p {
    color: #9a9a9a;
    height: 25px;
    line-height: 25px;
    font-size: 12px;
    width: 300px;
}

.page .post-item .content {
    padding: 0 102px;
    padding-bottom: 30px;
    background: #F9F9F9;
    overflow: hidden;
    position: relative;
    transition: all 0.3s;
    -webkit-transition: all 0.3s;
}

.page .post-item .content:hover {
    background-color: #f3f6f7;
}

.page .post-item .content .title {
    display: block;
    padding: 20px 0;
}

.page .post-item .content .title a {
    line-height: 21px;
    word-break: break-all;
    font-size: 16px;
    font-weight: bold;
}

.page .post-item .content .title a:hover {
    color: #3498DB;
}

.page .post-item .content .picture {
    display: block;
}

.page .post-item .content .picture img {
    display: block;
    width: 480px;
    margin: 0 auto;
}

.page .port{
    padding-left: 180px;
    height: 42px;
    background: white;
}

.page .port .bar {
    float: right;
}

.page .port .bar a {
    float: left;
    padding: 8px 0;
}

.page .port .bar a:hover {
    background-color: #eff3f5;
}

.page .port .bar a span {
    padding: 0 40px;
    height: 25px;
    line-height: 25px;
    font-size: 14px;
    color: #808080;
    transition: none;
    -webkit-transition: none;
}

.page .port .bar a:hover span {
    color: #3498DB;
}

.page .port .bar a i {
    font-size: 24px;
    padding-right: 10px;
    vertical-align: middle;
}

/* 分享 */
.page .port .share-bn{
    position:relative;
    z-index:10;
}
.page .port .share-bn ul{
    display:none;
    position:absolute;
    border-top:0;
    z-index:10;
    top:40px;
    left:-1px;
    box-shadow:0 3px 5px rgba(0,0,0,.1);
}
.page .port .share-bn ul li span:hover{
    background:#eff3f5;
}
.page .port .share-bn ul li span:hover em{
    color:#3498DB;
}
.page .port .share-bn ul span{
    display:block;
    padding:0 10px;
    width:122px;
    height:40px;
    line-height:40px;
    background:white;
    color:#808080;
}
.page .port .share-bn ul span em{
    padding-right:5px;
    font-size:24px;
    vertical-align:middle;
    color:#b5b5b5;
}
.page .port .share-bn:hover ul{
    display:block;
    position:absolute;
}
.page .port .share-bn .wx_code:hover img{
    display:block;
}
.page .port .share-bn li img{
    display:none;
    width:153px;
    height:153px;
    position:absolute;
    left:142px;
    top:0;
    box-shadow:0 0 5px rgba(0,0,0,.2);
    border-top:none;
}


/* 点赞 */
.page .port .bar .like {
    padding: 9px 0;
    padding-left: 42px;
}

.page .port .bar .on {
    background-color: rgb(239, 243, 245);
    color: rgb(52, 152, 219);
}

.page .port .bar .on i {
    color: rgb(255, 97, 97);
    text-shadow: rgb(255, 126, 188) 0 0 5px;
}

.page .port .bar .on em {
    color: rgb(52, 152, 219);
}

/* 提示 */
.default-hint {
    width: 100%;
    padding: 150px 0;
    text-align: center;
    background-color: white;
    border: 1px solid #e7eaf1;
    border-radius: 2px;
    box-shadow: 0 1px 3px rgba(0,37,55,.05);
    margin-bottom: 15px;
}

.default-hint strong {
    display: block;
}

.page .port .bar .like span {
    position: relative;
}

.page .port .bar .like span i {
    font-size: 22px;
    position: absolute;
    left: 0;
}

@keyframes like {
    0% {
        font-size: 22px;
        left: 0;
    }

    30% {
        font-size: 15px;
        left: 2px;
    }

    70% {
        font-size: 33px;
        content: "&#xe60a;";
        left: -5px;
    }

    100% {
        font-size: 22px;
        left: 0;
    }
}

@-webkit-keyframes like {
    0% {
        font-size: 22px;
        left: 0;
    }

    30% {
        font-size: 15px;
        left: 2px;
    }

    70% {
        font-size: 33px;
        content: "&#xe60a;";
        left: -5px;
    }

    100% {
        font-size: 22px;
        left: 0;
    }
}

@media only screen and ( max-width:  1140px) {
    .page {
        width: 800px;
        margin: 0 auto;
        float: none;
    }
    .sidebar {
        display: none;
    }
}


@media only screen and ( max-width: 800px ) {

    .page {
        width: 100%;
    }

    .page .post-item {
        box-shadow: none;
        border: none;
    }

    .page .post-item .post-head {
        padding: 10px 18px;
        height: 36px;
    }

    .default-hint {
        padding: 80px 0;
    }
    
    .page .port .share-bn:hover ul {
        display: none;
    }
    
    .page .post-item .post-head .avatar {
        width: 100%;
        height: 36px;
        line-height: 36px;
        display: block;
        border-radius: 0;
    }

    .page .post-item .post-head .avatar:hover {
        color: #3498DB;
    }

    .page .post-item .post-head .avatar .name {
        float: left;
        display: block;
        padding-left: 10px;
        font-size: 14px;
        font-weight: bold;
    }

    .page .post-item .post-head .avatar img {
        float: left;
        width: 35px;
        height: 35px;
        border-radius: 50%;
        vertical-align: middle;
    }

    .page .post-item .user-info {
        display: none;
    }

    .page .post-item .content {
        padding: 0;
        margin: 0;
    }

    .page .post-item .content .title {
        display: block;
        padding: 8px 20px;
        background-color: white;
    }

    .page .post-item .content .title a {
        font-weight: normal;
        word-break: break-all;
        font-size: 14px;
    }   

    .page .post-item .content .picture {
        display: block;
        padding: 10px 20px;
        background: #f7f7f7;
        text-align: center;
    }

    .page .post-item .content .picture img {
        width: 100%;
        max-width: 540px;
    }

    .page .post-item .port {
        width: 100%;
        padding: 0;
        height: 35px;
        line-height: 35px;
    }

    .page .post-item .port .bar {
        float: none;
    }

    .page .post-item .port .bar a {
        width: 33.3%;
        height: 35px;
        text-align: center;
        padding: 0;
        float: right;
    }

    .page .post-item .port .bar a span {
        padding: 0;
    }

    .page .post-item .port .bar a span i{
        font-size: 20px;
    }

    .page .post-item .port .bar .like span i {
        top: -4px;
        text-shadow: none !important;
    }
    .page .post-item .port .bar .like span {
        padding-left: 27px;
    }

    .page .port .bar a:hover {
        background-color: white;
    }
    .page .port .bar a:active {
        background-color: #eff3f5;
    }

    .page .port .bar a:hover span {
        color: #808080;
    }
    .page .port .bar a:active span {
        color: #3498DB;
    }
}
</style>

