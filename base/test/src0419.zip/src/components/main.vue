<template>
  <div class="main">
    <pic-page></pic-page>
    <pic-sidebar></pic-sidebar>
  </div>
</template>

<script>
  import PicPage from './page.vue'
  import PicSidebar from './sidebar.vue'
  export default{
        components: {
            'pic-page':PicPage,
            'pic-sidebar':PicSidebar
        }
   }
</script>
<style>
 .main{
   margin: 100px auto;
    max-width: 1100px;
    padding: 0 10px;
    overflow: hidden;
  }
</style>

