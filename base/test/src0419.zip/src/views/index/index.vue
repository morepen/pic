<template>
	<div>
		<top-header></top-header>
		<pic-main>1</pic-main>
		<footer-nav v-bind:class="{'isIndex':isNowPage}"></footer-nav>
	</div>
</template>

<script>
	import TopHeader from '../../components/header.vue'
	import FooterNav from '../../components/footer.vue'
	import PicMain from '../../components/main.vue'
	export default{
		components: {
			'footer-nav':FooterNav,
			'top-header': TopHeader,
			'pic-main':PicMain
		},
		data(){
			return{
				isNowPage: true
			}
		}
	}
</script>
