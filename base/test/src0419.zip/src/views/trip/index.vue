<template>
	<div id="header">
    <div class="head-main clearfix">
        <div class="band clearfix">
            <h1 class="logo"><a href="/">逗你的 一个正经网站</a></h1>
            <div class="port">
                <a href="/post/pass" class="iconfont">&#xe6de;</a>
                <a class="iconfont post-up">&#xe6e5;</a>
            </div>
        </div>
        <div class="menu">
            <ul class="clearfix">
                
                <li  class="on"  ><a href="/">最新</a></li>
                <li  ><a href="/week">周榜</a></li>
                <li  ><a href="/month">月榜</a></li>
                <li class="hid post"><a href="/post/pass">审贴</a></li>
                <li class="hid post-up"><a class="post-up" href="/post/up">投稿</a></li>
                <li class="user">
                    
                    <a href="/user/login">
                        登录
                    </a>
                    
                </li>
            </ul>
        </div>
        
        <div class="login">
            <a class="login-btn quick" href="javascript:void(0)"><i class="iconfont">&#xe606;</i>快速登录</a>
            <a class="login-btn login-quick" href="/user/login"><i class="iconfont">&#xe6f0;</i>站内登录</a>
            <a class="login-btn login-quick" href="/auths/qq"><i class="iconfont">&#xe607;</i>QQ&nbsp;登录</a>
            <a class="login-btn login-quick" href="/auths/wb"><i class="iconfont">&#xe652;</i>微博登录</a>
        </div>
        
    </div>
    <div class="head-phone">
        <i class="iconfont back">&#xe605;</i>
        <h1>逗你的 【正经网站】内涵图，搞笑图片</h1>
        <a href="/user/login" class="iconfont user">
            &#xe606;
        </a>
    </div>
</div>
</template>

<script>
	import FooterNav from '../../components/footer.vue'
	export default{
		components: {
			FooterNav
		},
		data(){
			return{
				isNowPage: true
			}
		}
	}
</script>
